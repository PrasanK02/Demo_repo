#!/bin/sh
CONSOLE_PATH='Cegedim/packages/Xamarin.UITest.0.6.7/tools/test-cloud.exe'
TEST_DIR_IOS='Cegedim/Cegedim.Test/bin/Debug'
# testclouddemo
ACCOUNT='3250166bbe78a884fbd6089582a8df7c'
IPA='Cegedim/cegedim.ipa'
DSYM_ZIP='Cegedim/MI.app.dSYM.zip'
DSYM='Cegedim/MI.app.dSYM'

# Pull the ipa
# This sharelink may expire
curl -L https://www.dropbox.com/s/j7ej40nmddvm7m9/MI.ipa\?dl\=0 -o $IPA
curl -L https://www.dropbox.com/s/iwsromblhk5dpok/MI.app.dSYM.zip\?dl\=0 -o $DSYM_ZIP

# Unzip the zipped dSym
unzip $DSYM_ZIP -d Cegedim/
 
# ios7 
iOS7='bc7c60f7'
 
# ios7 and 8  - small temp
LARGE_SUBSET='6e0ca4ec'
 
echo "Uploading the file $IPA to Test Cloud on device set $iOS7"
mono $CONSOLE_PATH submit "$IPA" $ACCOUNT --devices $iOS7 --assembly-dir $TEST_DIR_IOS --dsym $DSYM --series "Jenkins" --locale "en_US" --nunit-xml report.xml
