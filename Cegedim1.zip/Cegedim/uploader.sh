#!/bin/sh
CONSOLE_PATH='test-cs/Cegedim/packages/Xamarin.UITest.0.6.6/tools/test-cloud.exe'
TEST_DIR_IOS='test-cs/Cegedim/Cegedim.Automation/bin/Debug'
# testclouddemo
ACCOUNT='e2756ca2130df973d555d7a5efe51d43'
IPA='app/latest/cegedim.ipa'

# Pull the ipa
# This sharelink may expire
curl -L https://www.dropbox.com/s/j7ej40nmddvm7m9/MI.ipa\?dl\=1 -o $IPA
 
# No iOS 8
SMALL_SUBSET='a184f9ee'
 
# No iOS 8
LARGE_SUBSET='12aef708'
 
if (( $# == 0 )); then
  echo "Uploading the file $IPA to Test Cloud on device set $SMALL_SUBSET"
  mono $CONSOLE_PATH submit "$IPA" $ACCOUNT --devices $SMALL_SUBSET_SUBSET --assembly-dir $TEST_DIR_IOS --series
  "Jenkins" --locale "en_US" --nunit-xml report.xml
fi
 
if (( $# == 1 )); then
  echo  "Uploading the file $IPA to Test Cloud on device set $1"
  mono $CONSOLE_PATH_PATH submit "$IPA" $ACCOUNT --devices $1 --assembly-dir $TEST_DIR_IOS --series "Jenkins"
  --locale "en_US" --nunit-xml report.xml
fi
