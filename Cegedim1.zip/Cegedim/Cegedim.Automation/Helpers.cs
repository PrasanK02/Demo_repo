﻿using System;
using System.Threading;

namespace Cegedim.Automation {
    public static class Helpers {
        
    }
}