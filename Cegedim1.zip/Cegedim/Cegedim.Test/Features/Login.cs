﻿using NUnit.Framework;
using System;
using Cegedim.Automation;


namespace Cegedim
{
    [TestFixture]
    [Category("BasicTest")]
    public class Login 
    {
        private MITouch m_app;

        [SetUp]
        public void Setup() {
            m_app = MITouch.Launch();
        }

        //[Test]
        public void Launch() {

        }

        [Test]
        public void ValidCredentials() {
            var loginPage = m_app.GetLoginPage();
            m_app.Screenshot("I'm on the login page");

            loginPage.Username = "jmayo";
            loginPage.Password = "cegedim";
            m_app.Screenshot("I've entered valid credentials");

            var dashboard = loginPage.SubmitCredentials();
            m_app.Screenshot("I'm on the dashboard page");
        }

        [Test]
        public void InvalidCredentials() {
            var loginPage = m_app.GetLoginPage();
            m_app.Screenshot("I'm on the login page");

            loginPage.Username = "jmay";
            loginPage.Password = "cegy";
            m_app.Screenshot("I've entered invalid credentials");

            var invalidPage = loginPage.SubmitInvalidCredentials();
            m_app.Screenshot("I'm still on the login page");
        }       
    }
}
