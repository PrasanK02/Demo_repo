﻿using NUnit.Framework;
using System;
using Cegedim.Automation;

namespace Cegedim {

    [TestFixture()]
    public class ToDo {
        MITouch m_miTouch;

        // Method names here matter because of the test ordering
        [Test()]
        public void A_MakeTodoItem() {
            var todoPage = Background();
            todoPage.DeleteAllTodosWithSubject("Present Test Cloud");
            m_miTouch.Screenshot("I delete all todos with subject 'Present Test Cloud'");

            var todoPopover = todoPage.CreateTodoPopover();
            m_miTouch.Screenshot("I tap the add a todo item button and see the To do dialog");

            todoPopover.Subject = "Present Test Cloud";
            m_miTouch.Screenshot("I set the item subject to 'Present Test Cloud'");

            todoPopover.Description = "make sure we cover all the gotchas";
            m_miTouch.Screenshot("I set the item description to 'make sure we cover all the gotchas'");

            todoPopover.DueDate = NextTuesday();
            m_miTouch.Screenshot("I set the due date for next tuesday");

            todoPopover.Reminder = "30 Minutes";
            m_miTouch.Screenshot("I want to be reminder 30 minutes before the meeting");

            todoPopover.Channel = "Face to Face";
            m_miTouch.Screenshot("I set the todo channel to Face to Face");

            todoPopover.AddAssigneeFromDatabase();
            m_miTouch.Screenshot("I assign the task to a teammate");

            var todoPageRevisited = todoPopover.DoneReturnToTodoPage();
            todoPageRevisited.ConfirmTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("I'm done creating the todo item and I see it in the Todos list");
        }

        [Test]
        public void ChangeTheTodoChannel() {
            var todoPage = Background();
            todoPage.TodoType = "Received";
            todoPage.ConfirmTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("There is a 'Present Test Cloud' todo item in my received list");

            var editTodoPopover = todoPage.EditTodoPopover("Present Test Cloud");
            editTodoPopover.Channel = "Fax";
            var todoPageRevisited = editTodoPopover.DoneReturnToTodoPage();
            todoPageRevisited.ConfirmTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("I edit the todo item and change the channel to Fax");

            todoPageRevisited.MoreDetails();
            todoPageRevisited.ConfirmDetail("Fax");
            m_miTouch.Screenshot("I should see the channel changed in the todo details");
        }

        [Test]
        public void DeleteTodoItem() {
            var todoPage = Background();
            todoPage.TodoType = "Received";
            todoPage.ConfirmTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("There is a 'Present Test Cloud' todo item in my received list");

            todoPage.DeleteTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("I delete the current todo item");

            todoPage.TodoType = "Received";
            m_miTouch.Screenshot("I select the received todo type");

            todoPage.ConfirmNoTodoItem("Present Test Cloud");
            m_miTouch.Screenshot("I shouldnt see the todo item");
        }

        public TodoPage Background() {
            m_miTouch = Globals.App;
            var dashboard = Globals.QuickSetUp();
            m_miTouch.Screenshot("I'm on the dashboard page");

            var todoPage = dashboard.NavigateToTodoPage();
            m_miTouch.Screenshot("I am on the todo page");

            return todoPage;
        }

        public DateTime NextTuesday() {
            var currentDateTime = DateTime.Now;
            var daysUntilNextTuesday = ((int)DayOfWeek.Tuesday - (int)currentDateTime.DayOfWeek + 7) % 7;
            if (daysUntilNextTuesday == 0)
                daysUntilNextTuesday = 7;
            // Set Next Tuesday at 11:30 AM
            var nextTuesday = currentDateTime.AddDays((double)daysUntilNextTuesday).Date + new TimeSpan(11, 30, 0);
            return nextTuesday;
        }
    }
}

