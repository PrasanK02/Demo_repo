﻿using NUnit.Framework;
using System;
using Cegedim.Automation;

namespace Cegedim {

    [TestFixture()]
    [Category("BasicTest")]
    public class CallDependentData {
        MITouch m_miTouch;

        [Test()]
        public void CreateAndFinishDataDependentCall() {
            var callPage = Background();
            m_miTouch.Screenshot("I am on the call page");

            callPage.DetailFirstProduct();
            callPage.AddProfiledAttendee(2);
            callPage.AddSpeaker();
            m_miTouch.Screenshot("I've added a speaker");

            callPage.CallPurpose = "Ordering"; // Set the Call Purpose
            m_miTouch.Screenshot("I've added a call purpose");

            callPage.NavigateToPostCallTab();
            callPage.AddCallDialogues();
            m_miTouch.Screenshot("I've added a call dialog");

            var searchPage = callPage.Finish();
            var dashboardPage = searchPage.NavigateToDashboardPage();
            var plannerPage = dashboardPage.NavigateToPlannerPage();
            m_miTouch.Screenshot("I should be able to complete a data dependent call");

            plannerPage.VerifyCalls();
            m_miTouch.Screenshot("I see the call was recorded correctly");
        }

        public CallPage Background(){
            m_miTouch = Globals.App;
            var dashboard = Globals.QuickSetUp();
            var searchPage = dashboard.NavigateToSearchPage();

            // Does some database queries to search for a customer
            var callPage = searchPage.NavigateToCallPage();
            return callPage;
        }
    }
}